#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon May 21 11:10:27 2018

@author: syamherle
"""
import os
import pandas as pd
import numpy as np
from flask import Flask,abort,jsonify,request,render_template
import pickle 
import sqlite3
from sqlite3 import Error
import collections



def create_connection(path):
    db_file = path+"/db/pythonsqlite.db"
    try:
        conn = sqlite3.connect(db_file)
        return conn
    except Error as e:
        print(e)
    return None


def get_candidates(mat,user_index,user_list):
    
    vector = mat[user_index,:]
    matrix = mat
    dotted = matrix.dot(vector)
    matrix_norms = np.linalg.norm(matrix, axis=1)
    vector_norm = np.linalg.norm(vector)
    matrix_vector_norms = np.multiply(matrix_norms, vector_norm)
    neighbors = np.divide(dotted, matrix_vector_norms)
    neighbors_name ={v:neighbors[v] for v in range(len(neighbors))}
    
    top_features = collections.Counter(neighbors_name)
    top_features_k = top_features.most_common(50)
    #Remove same users variance vector
    top_features_k.pop(0)
    similar_users = [user_list[k[0]] for k in top_features_k]
    
    return similar_users
    
        
def get_simillar_user(mat,usr):
    
    mat_1 = mat[:,0:]
    
    user_list = list(mat_1[:,0])
    try:
        user_index = user_list.index(usr)
    except ValueError:
        return render_template('pagenotfound.html')
    mat_2 = mat_1[:,0:]
    
    val = get_candidates(mat_2,user_index,user_list)
     
    bigger_row=[]
    row=[]
    for i in range(len(val)):
        row.append(val[i])
        row.append(user_interest[user_interest['user_handle'] == val[i]]['interest_tag'].iloc[0])
       
        bigger_row.append(row)
        row=[]
 
    
    return bigger_row

# =============================================================================
# def get_summary(user_ls,mat,val):
#     mat_1 = mat[:,1:]
#     
#     user_list = list(mat_1[:,0])
#     
#     try:
#         user_list.index(val)
#     except ValueError:
#         return render_template('pagenotfound.html')
#     
#     
#     bigger_row=[] 
#     row=[]
#     for i in range(len(user_ls)):
#         row.append(user_ls[i])
#         row.append(user_interest[user_interest['user_handle'] == user_ls[i]]['interest_tag'].iloc[0])
#       
#         bigger_row.append(row)
#         row=[]
#     #val=user_interest[user_interest['user_handle'] == user_ls[0]]['interest_tag']
#     return bigger_row
# 
# =============================================================================



app = Flask(__name__)


@app.route('/',methods=['GET', 'POST'])
def home():
    return render_template('index.html')



@app.route('/result',methods=['GET','POST'])
def bind_result():
    
    #make a connection to database and get the table
    text = request.form['user_handle']
    user_ip_handle = int(text)
    
    
    #pandas to numpy
    
    row_row = get_simillar_user(feature_space_numpy,user_ip_handle)
    
    #row_row = get_summary(get_top_user)
    
    if len(row_row[0])>1:
        return render_template('pagination.html',row_row=row_row)
    else:
        return render_template('pagenotfound.html')
    #return str(row_row)
   

    
if __name__ == '__main__':
    global feature_space_numpy,feature_space
    path =os.getcwd()
    conn = create_connection(path)
    if conn is not None:
        feature_space = pd.read_sql_query("select * from featurespace;", conn,index_col=None)
        user_interest = pd.read_sql_query("select * from userinterest;", conn)
        
    feature_space_numpy = feature_space.as_matrix(columns=None)
    app.run(port=9090,debug=True)
