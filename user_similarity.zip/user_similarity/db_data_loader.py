#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon May 21 10:17:55 2018

@author: syamherle
"""
import os
import pandas as pd
import sqlite3
from sqlite3 import Error




    
def create_connection(path):
    db_file = path+"/db/pythonsqlite.db"
    try:
        conn = sqlite3.connect(db_file)
        return conn
    except Error as e:
        print(e)
    return None

def convert_csv_to_table(path,conn):
    
    dataFrame1 = pd.read_csv(path+'/data/course_tags.csv')
    dataFrame1.to_sql('coursetags', conn, if_exists='fail', index=False)
    
    dataFrame2 = pd.read_csv(path+'/data/user_assessment_scores.csv')
    dataFrame2.to_sql('usercourseassessment', conn, if_exists='fail', index=False)
    
    dataFrame3 = pd.read_csv(path+'/data/user_course_views.csv')
    dataFrame3.to_sql('usercourseview', conn, if_exists='fail', index=False)
    
    dataFrame4 = pd.read_csv(path+'/data/user_interests.csv')
    dataFrame4.to_sql('userinterest', conn, if_exists='fail', index=False)
    
    dataFrame5 = pd.read_csv(path+'/data/feature_space.csv')
    dataFrame5.to_sql('featurespace', conn, if_exists='fail', index=False)
        
def main():
    
    path =os.getcwd()
    conn = create_connection(path)
    if conn is not None:
        convert_csv_to_table(path,conn)
    else:
        print("Error! cannot create the database connection.")

if __name__ == "__main__":
    main()



